package de.squeezzy.playerinventory.items;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class PlayerInventoryItems {

    public ItemStack openInventory() {

        ItemStack item = new ItemStack(Material.BUNDLE);
        ItemMeta meta = item.getItemMeta();
        assert meta != null;
        meta.setDisplayName("§l§eInventory");
        ArrayList<String> lore = new ArrayList<>();
        lore.add("§fPress §eright click §fto open your Inventory§l§f!");
        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    public ItemStack whiteGlasPane() {

        ItemStack item = new ItemStack(Material.WHITE_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();

        assert meta != null;
        meta.setDisplayName(" ");
        item.setItemMeta(meta);

        return item;
    }
}
