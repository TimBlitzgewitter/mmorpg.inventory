package de.squeezzy.playerinventory.items.allitems;

import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Items {

    public ItemStack air() {

        return new ItemStack(Material.AIR);
    }

    public ItemStack woodensword() {

        ItemStack item = new ItemStack(Material.WOODEN_SWORD);
        ItemMeta meta = item.getItemMeta();
        assert meta != null;
        meta.setDisplayName("§l§6Wooden Sword");
        item.setItemMeta(meta);

        return item;
    }

    public ItemStack stonesword() {

        ItemStack item = new ItemStack(Material.STONE_SWORD);
        ItemMeta meta = item.getItemMeta();
        assert meta != null;
        meta.setDisplayName("§l§6Stone Sword");
        item.setItemMeta(meta);

        return item;
    }


    public ItemStack stick() {

        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        assert meta != null;
        meta.setDisplayName("§l§6Wooden Stick");
        item.setItemMeta(meta);

        return item;
    }
}
